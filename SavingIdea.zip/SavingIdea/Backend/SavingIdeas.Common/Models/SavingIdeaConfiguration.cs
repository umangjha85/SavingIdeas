﻿namespace SavingIdeas.Common.Models
{
    public class SavingIdeaConfiguration
    {
        public ConnectionStrings ConnectionStrings { get; set; }

    }
}
