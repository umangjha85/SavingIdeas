﻿using System;
using Newtonsoft.Json;

namespace SavingIdeas.Common.Models
{
    public class IdeaFromExcel
    {
        [JsonProperty("year")]
        public string Year { get; set; }
        [JsonProperty("sector")]
        public string Sector { get; set; }
        [JsonProperty("l1 commodity")]
        public string L1Commodity { get; set; }
        [JsonProperty("supplier code")]
        public string SupplierCode { get; set; }
        [JsonProperty("supplier name")]
        public string SupplierName { get; set; }
        [JsonProperty("responsibility")]
        public string Responsibility { get; set; }
        [JsonProperty("l5 commodity")]
        public string L5Commodity { get; set; }
        [JsonProperty("part #")]
        public string Part { get; set; }
        [JsonProperty("part description")]
        public string PartDescription { get; set; }
        [JsonProperty("nego saving lever")]
        public string NegoSavingLever { get; set; }
        [JsonProperty("derived thru spend analytics (y/n)")]
        public string DerivedthruSpendAnalyticsYN { get; set; }
        [JsonProperty("applicable model")]
        public string ApplicableModel { get; set; }
        [JsonProperty("saving/veh or %")]
        public double SavingVehor { get; set; }
        [JsonProperty("applicable supplier volume")]
        public double ApplicableSupplierVolume { get; set; }
        [JsonProperty("f20 cashflow saving \n(rs. crs.)")]
        public double F20CashflowSavingRsCrs { get; set; }
        [JsonProperty("confidence level")]
        public string ConfidenceLevel { get; set; }
        [JsonProperty("sap/cn")]
        public string SaPCN { get; set; }
        [JsonProperty("effectivity date")]
        public DateTime EffectivityDate { get; set; }
        [JsonProperty("remarks")]
        public string Remarks { get; set; }
        [JsonProperty("implementation status")]
        public string ImplementationStatus { get; set; }

    }
}