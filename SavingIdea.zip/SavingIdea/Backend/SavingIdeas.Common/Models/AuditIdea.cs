﻿using System;

namespace SavingIdeas.Common.Models
{
    public class AuditIdea
    {
        public int AuditIdeaId { get; set; }
        public Guid RecordUpdateId { get; set; }
        public int? IdeaId { get; set; }
        public string AttributeName { get; set; }
        public string OldValue { get; set; }
        public string UpdatedValue { get; set; }
        public bool Deleted { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}