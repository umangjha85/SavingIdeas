﻿namespace SavingIdeas.Common.Models
{
    public class ConnectionStrings
    {
        public string SavingIdeaDataContext { get; set; }
    }
}