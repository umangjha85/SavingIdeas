﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavingIdeas.Common.Models.Interface
{
    public interface IAuditRepository
    {
        Task<List<AuditIdea>> GetAuditInfoByIdeaIdAsync(int ideaId);
    }
}