﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavingIdeas.Common.Models.Interface
{
    public interface ISavingIdeaRepository
    {
        Task ImportDataAsync(List<IdeaFromExcel> ideas);
        Task<Idea> AddIdeaAsync(Idea idea);
        Task<Idea> GetIdeaByIdAsync(int ideaId);
        Task<List<Idea>> GetIdeaAsync();
        Task UpdateIdeaAsync(Dictionary<string, object> dataKeyValue);
        Task DeleteIdeaByIdAsync(int ideaId);
    }
}