﻿using System;
using Newtonsoft.Json;

namespace SavingIdeas.Common.Models
{
    public class Idea
    {
        [JsonProperty("IdeaId")]
        public int? IdeaId { get; set; }
        [JsonProperty("Year")]
        public string Year { get; set; }
        [JsonProperty("Sector")]
        public string Sector { get; set; }
        [JsonProperty("L1Commodity")]
        public string L1Commodity { get; set; }
        [JsonProperty("SupplierCode")]
        public string SupplierCode { get; set; }
        [JsonProperty("SupplierName")]
        public string SupplierName { get; set; }
        [JsonProperty("Responsibility")]
        public string Responsibility { get; set; }
        [JsonProperty("L5Commodity")]
        public string L5Commodity { get; set; }
        [JsonProperty("Part")]
        public string Part { get; set; }
        [JsonProperty("PartDescription")]
        public string PartDescription { get; set; }
        [JsonProperty("NegoSavingLever")]
        public string NegoSavingLever { get; set; }
        [JsonProperty("DerivedthruSpendAnalyticsYN")]
        public string DerivedthruSpendAnalyticsYN { get; set; }
        [JsonProperty("ApplicableModel")]
        public string ApplicableModel { get; set; }
        [JsonProperty("SavingVehor")]
        public double? SavingVehor { get; set; }
        [JsonProperty("ApplicableSupplierVolume")]
        public double? ApplicableSupplierVolume { get; set; }
        [JsonProperty("F20CashflowSavingRsCrs")]
        public double? F20CashflowSavingRsCrs { get; set; }
        [JsonProperty("ConfidenceLevel")]
        public string ConfidenceLevel { get; set; }
        [JsonProperty("SaPCN")]
        public string SaPCN { get; set; }
        [JsonProperty("EffectivityDate")]
        public DateTime? EffectivityDate { get; set; }
        [JsonProperty("Remarks")]
        public string Remarks { get; set; }
        [JsonProperty("ImplementationStatus")]
        public string ImplementationStatus { get; set; }
        [JsonProperty("Created")]
        public DateTime? Created { get; set; }
        [JsonProperty("LastUpdated")]
        public DateTime? LastUpdated { get; set; }
    }
}