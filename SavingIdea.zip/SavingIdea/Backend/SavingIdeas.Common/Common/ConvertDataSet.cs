﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace SavingIdeas.Common.Common
{
    public static class ConvertDataSet
    {
        public static List<T> ConvertToList<T>(DataTable dt)
        {
            var columnNames = dt.Columns.Cast<DataColumn>()
                .Select(c => c.ColumnName.ToLower()).ToList();
            var properties = typeof(T).GetProperties();
            return dt.AsEnumerable().Select(row =>
            {
                var objT = Activator.CreateInstance<T>();
                foreach (var pro in properties)
                {
                    //ToDo: Need to wor on good logic over here to fetch column name
                    var columnNameJsonAttribute = pro.GetCustomAttributesData()?[0].ToString().Split("\"")?[1];
                    if (columnNames.Contains(columnNameJsonAttribute))
                    {
                        try
                        {
                            pro.SetValue(objT, row[columnNameJsonAttribute]);
                        }
                        catch (Exception ex) { }
                    }
                }
                return objT;
            }).ToList();
        }
    }
}
