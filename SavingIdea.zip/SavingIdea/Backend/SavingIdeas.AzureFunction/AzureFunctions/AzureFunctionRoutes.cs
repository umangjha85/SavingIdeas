namespace SavingIdeas.AzureFunction.AzureFunctions
{
    public static class AzureFunctionRoutes
    {
        public const string ServerStatus = "ServerStatus";
        public const string ImportFile = "ImportFile";
        public const string IdeaById = "savingidea/{id}";
        public const string Idea = "savingidea";
        public const string IdeaAuditById = "savingidea/audit/{id}";
    }
}