﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SavingIdeas.Common.Models;
using SavingIdeas.Common.Models.Interface;
using SavingIdeas.EFCore.Repository;

namespace SavingIdeas.AzureFunction.AzureFunctions
{
    public class CrudAzureFunction
    {
        private readonly ISavingIdeaRepository _savingIdeaRepository;
        private readonly ILogger<CrudAzureFunction> _logger;
        
        public CrudAzureFunction(
            ISavingIdeaRepository savingIdeaRepository,
            ILogger<CrudAzureFunction> logger)
        {
            _savingIdeaRepository = savingIdeaRepository;
            _logger = logger;

        }

        [FunctionName("GetIdeaById")]
        public async Task<Idea> GetIdeaByIdAsync(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = AzureFunctionRoutes.IdeaById)] HttpRequest req,
            int id)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            return await _savingIdeaRepository.GetIdeaByIdAsync(id).ConfigureAwait(false);
        }

        [FunctionName("UpdateIdea")]
        public async Task<IActionResult> UpdateIdeaAsync(
            [HttpTrigger(AuthorizationLevel.Anonymous, "patch", Route = AzureFunctionRoutes.Idea)]
            JObject idea)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
            var dataKeyValue = JsonConvert.DeserializeObject<Dictionary<string, object>>(idea.ToString());
            await _savingIdeaRepository.UpdateIdeaAsync(dataKeyValue).ConfigureAwait(false);
            return new NoContentResult();
        }

        [FunctionName("DeleteIdeaById")]
        public async Task<IActionResult> DeleteIdeaByIdAsync(
            [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = AzureFunctionRoutes.IdeaById)] HttpRequest req,
            int id)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

             await _savingIdeaRepository.DeleteIdeaByIdAsync(id).ConfigureAwait(false);
            return new NoContentResult();
        }

        [FunctionName("GetIdea")]
        public async Task<List<Idea>> GetIdeaAsync(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = AzureFunctionRoutes.Idea)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            return await _savingIdeaRepository.GetIdeaAsync().ConfigureAwait(false);
        }

        [FunctionName("AddIdea")]
        public async Task<IActionResult> AddIdeaAsync(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = AzureFunctionRoutes.Idea)]
            Idea idea,
            ILogger log)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
            log.LogInformation("Body: {0}", JsonConvert.SerializeObject(idea));

            if (idea == null || idea.EffectivityDate == null)
            {
                return new BadRequestObjectResult("Please pass idea details.");
            }
            var newIdea = await _savingIdeaRepository.AddIdeaAsync(idea).ConfigureAwait(false);
            return new OkObjectResult(newIdea);
        }
    }
}
