using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ExcelDataReader;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using SavingIdeas.Common.Common;
using SavingIdeas.Common.Models;
using SavingIdeas.Common.Models.Interface;
using SavingIdeas.EFCore.Repository;

namespace SavingIdeas.AzureFunction.AzureFunctions
{
    public class ImportFileAzureFunction
    {
        private readonly ISavingIdeaRepository _savingIdeaRepository;
        private readonly ILogger<ImportFileAzureFunction> _logger;
        
        public ImportFileAzureFunction(
            ISavingIdeaRepository savingIdeaRepository,
            ILogger<ImportFileAzureFunction> logger)
        {
            _savingIdeaRepository = savingIdeaRepository;
            _logger = logger;

        }
        
        [FunctionName("ServerStatus")]
        public IActionResult ServerStatus(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = AzureFunctionRoutes.ServerStatus)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            return new OkObjectResult("Server Up & Running !!!");
        }

        [FunctionName("ImportFile")]
        public async Task<IActionResult> ImportFileAsync(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = AzureFunctionRoutes.ImportFile)] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
            var file = req.Form.Files["ideas"];
            List<IdeaFromExcel> response = new List<IdeaFromExcel>();
            if (file != null)
            {
                if (file.ContentType.Equals("application/vnd.ms-excel", StringComparison.CurrentCultureIgnoreCase)
                    || file.ContentType.Equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        StringComparison.CurrentCultureIgnoreCase))
                {
                    using (var stream = file.OpenReadStream())
                    {
                        using (var reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                            {
                                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                                {
                                    UseHeaderRow = true
                                }
                            });
                            response = ConvertDataSet.ConvertToList<IdeaFromExcel>(result.Tables[0]);
                        }
                    }
                }
                else if (file.ContentType.Equals("text/csv",
                    StringComparison.CurrentCultureIgnoreCase))
                {
                    using (var stream = file.OpenReadStream())
                    {
                        using (var reader = ExcelReaderFactory.CreateCsvReader(stream))
                        {
                            var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                            {
                                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                                {
                                    UseHeaderRow = true
                                }
                            });
                            response = ConvertDataSet.ConvertToList<IdeaFromExcel>(result.Tables[0]);
                        }
                    }
                }
                else
                {
                    return new BadRequestObjectResult("Please upload either Excel[.xls,.xlsx] or CSV");
                }

            }
            else
            {
                return new BadRequestObjectResult("Send a file with attachment name \"ideas\"");
            }

            if (response.Count == 0)
            {
                return new BadRequestObjectResult("No data found for processing");
            }
            await _savingIdeaRepository.ImportDataAsync(response).ConfigureAwait(false);
            return new NoContentResult();
        }
    }
}
