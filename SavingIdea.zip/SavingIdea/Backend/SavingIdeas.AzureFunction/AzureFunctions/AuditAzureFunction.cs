﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Extensions.Logging;
using SavingIdeas.Common.Models;
using SavingIdeas.Common.Models.Interface;

namespace SavingIdeas.AzureFunction.AzureFunctions
{
    public class AuditAzureFunction
    {
        private readonly IAuditRepository _auditRepository;
        private readonly ILogger<AuditAzureFunction> _logger;

        public AuditAzureFunction(
            IAuditRepository auditRepository,
            ILogger<AuditAzureFunction> logger)
        {
            _auditRepository = auditRepository;
            _logger = logger;
        }

        [FunctionName("GetIdeaAuditById")]
        public async Task<List<AuditIdea>> IdeaAuditById(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = AzureFunctionRoutes.IdeaAuditById)] HttpRequest req,
            int id)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");

            return await _auditRepository.GetAuditInfoByIdeaIdAsync(id).ConfigureAwait(false);
        }

    }
}
