﻿using AutoMapper;
using SavingIdeas.Common.Models;
using SavingIdeas.EFCore.Models;

namespace SavingIdeas.EFCore.Mapper
{
    public static class EntityAutoMapper
    {
        public static IMapper Mapper;

        static EntityAutoMapper()
        {
            var config = new MapperConfiguration(
                cfg =>
                {
                    cfg.CreateMap<IdeaFromExcel, IdeaEntity>()
                        .ForMember(q => q.IdeaId, option => option.Ignore())
                        .ForMember(q => q.AuditData, option => option.Ignore())
                        .ForMember(q => q.Created, option => option.Ignore())
                        .ForMember(q => q.LastUpdated, option => option.Ignore());
                    cfg.CreateMap<IdeaEntity, IdeaFromExcel>();
                    cfg.CreateMap<Idea, IdeaEntity>()
                        .ForMember(q => q.AuditData, option => option.Ignore());
                    cfg.CreateMap<IdeaEntity, Idea>();
                    cfg.CreateMap<AuditIdeaEntity, AuditIdea>();
                }
            );
            config.AssertConfigurationIsValid();
            Mapper = config.CreateMapper();
        }

    }
}
