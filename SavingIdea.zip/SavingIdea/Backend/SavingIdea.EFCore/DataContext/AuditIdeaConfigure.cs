﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SavingIdeas.EFCore.Models;

namespace SavingIdeas.EFCore.DataContext
{
    public partial class SavingIdeaDataContext
    {
        public DbSet<AuditIdeaEntity> AuditIdeas { get; set; }
        private void AuditIdeaConfigure(EntityTypeBuilder<AuditIdeaEntity> entity)
        {
            entity.ToTable("AuditIdea", "dba");

            entity.HasKey(k => k.AuditIdeaId);
            entity.Property(k => k.AuditIdeaId)
                .ValueGeneratedOnAdd();
            entity
                .HasOne(k => k.IdeaEntity)
                .WithMany(i => i.AuditData);

        }

    }
}
