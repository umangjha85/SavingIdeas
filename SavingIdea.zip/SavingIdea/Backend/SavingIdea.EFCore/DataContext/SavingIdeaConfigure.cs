﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SavingIdeas.EFCore.Models;

namespace SavingIdeas.EFCore.DataContext
{
    public partial class SavingIdeaDataContext
    {
        public DbSet<IdeaEntity> Ideas { get; set; }
        private void SavingIdeaConfigure(EntityTypeBuilder<IdeaEntity> entity)
        {
            entity.ToTable("Idea","dba");
            entity
                .HasKey(k => k.IdeaId);
            entity
                .HasMany(e => e.AuditData)
                .WithOne(a=>a.IdeaEntity);
               

            entity.Property(p => p.IdeaId)
                .ValueGeneratedOnAdd();
            entity.Property(p => p.Created)
                .HasDefaultValueSql("getdate()");
            entity.Property(p => p.LastUpdated)
                .HasDefaultValueSql("getdate()")
                .ValueGeneratedOnAddOrUpdate();
        }
        
    }
}
