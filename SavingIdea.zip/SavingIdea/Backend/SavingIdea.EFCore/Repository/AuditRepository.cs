﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SavingIdeas.Common.Models;
using SavingIdeas.Common.Models.Interface;
using SavingIdeas.EFCore.DataContext;
using SavingIdeas.EFCore.Mapper;
using SavingIdeas.EFCore.Models;

namespace SavingIdeas.EFCore.Repository
{
    public class AuditRepository : IAuditRepository
    {
        private readonly SavingIdeaDataContext _savingIdeaDataContext;
        private readonly ILogger<SavingIdeaRepository> _logger;

        public AuditRepository(
            SavingIdeaDataContext savingIdeaDataContext,
            ILogger<SavingIdeaRepository> logger)
        {
            _savingIdeaDataContext = savingIdeaDataContext;
            _logger = logger;
        }

        public async Task<List<AuditIdea>> GetAuditInfoByIdeaIdAsync(int ideaId)
        {
            try
            {
                var auditIdea = await _savingIdeaDataContext.AuditIdeas
                    .Where(i => i.IdeaId == ideaId)
                    .ToListAsync()
                    .ConfigureAwait(false);
                return EntityAutoMapper.Mapper.Map<List<AuditIdeaEntity>, List<AuditIdea>>(auditIdea);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

    }
}