﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SavingIdeas.Common.Models;
using SavingIdeas.Common.Models.Interface;
using SavingIdeas.EFCore.DataContext;
using SavingIdeas.EFCore.Mapper;
using SavingIdeas.EFCore.Models;

namespace SavingIdeas.EFCore.Repository
{
    public class SavingIdeaRepository : ISavingIdeaRepository
    {
        private readonly SavingIdeaDataContext _savingIdeaDataContext;
        private readonly ILogger<SavingIdeaRepository> _logger;
        
        private static IDictionary<string, object> IdeaDicEntity = new Dictionary<string, object>();
        private static IDictionary<string, Object> auditKeyValue = new Dictionary<string, Object>();
        public SavingIdeaRepository(
            SavingIdeaDataContext savingIdeaDataContext,
            ILogger<SavingIdeaRepository> logger)
        {
            _savingIdeaDataContext = savingIdeaDataContext;
            _logger = logger;
        }

        public async Task ImportDataAsync(List<IdeaFromExcel> ideas)
        {
            var data = EntityAutoMapper.Mapper.Map<List<IdeaFromExcel>, List<IdeaEntity>>(ideas);
            using (var transaction = _savingIdeaDataContext.Database.BeginTransaction())
            {
                try
                {
                    await _savingIdeaDataContext.Ideas.AddRangeAsync(data)
                        .ConfigureAwait(false);
                    await _savingIdeaDataContext.SaveChangesAsync()
                        .ConfigureAwait(false);

                    // Commit transaction if all commands succeed, transaction will auto-rollback
                    // when disposed if either commands fails
                    await transaction.CommitAsync().ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.Message);
                    throw;
                }
            }
        }

        public async Task<Idea> AddIdeaAsync(Idea idea)
        {
            idea.IdeaId = null;
            idea.Created = null;
            idea.LastUpdated = null;
            var savingIdea = EntityAutoMapper.Mapper.Map<Idea, IdeaEntity>(idea);
            try
            {
                await _savingIdeaDataContext.Ideas.AddAsync(savingIdea)
                    .ConfigureAwait(false);
                await _savingIdeaDataContext.SaveChangesAsync()
                   .ConfigureAwait(false);
                return EntityAutoMapper.Mapper.Map<IdeaEntity,Idea>(savingIdea);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public async Task<Idea> GetIdeaByIdAsync(int ideaId)
        {
            try
            {
                var idea = await _savingIdeaDataContext.Ideas
                    .SingleAsync(i => i.IdeaId == ideaId)
                    .ConfigureAwait(false);
                return EntityAutoMapper.Mapper.Map<IdeaEntity, Idea>(idea);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public async Task<List<Idea>> GetIdeaAsync()
        {
            try
            {
                var ideas = await _savingIdeaDataContext.Ideas
                    .ToListAsync()
                    .ConfigureAwait(false);
                return EntityAutoMapper.Mapper.Map<List<IdeaEntity>, List<Idea>>(ideas);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public async Task UpdateIdeaAsync(Dictionary<string, object> dataKeyValue)
        {
            try
            {
                IdeaDicEntity.Clear();
                var idea = await _savingIdeaDataContext.Ideas
                                   .SingleAsync(i => i.IdeaId == Convert.ToInt32(dataKeyValue["IdeaId"]))
                                   .ConfigureAwait(false);
                IdeaDicEntity = JsonConvert.DeserializeObject<Dictionary<string, object>>(JsonConvert.SerializeObject(idea));
                
                var id = Convert.ToInt32(dataKeyValue["IdeaId"]);
                Guid recordId = Guid.NewGuid();
                foreach (var keyEntity in IdeaDicEntity.Keys.ToList())
                {
                   
                    foreach (var keyPayLoad in dataKeyValue.Keys.ToList())
                    {
                       
                        if (keyEntity == keyPayLoad && keyEntity != "IdeaId" )
                        {
                            var oldValue = IdeaDicEntity[keyEntity].ToString();
                            var newValue = dataKeyValue[keyPayLoad].ToString();
                            if (oldValue != newValue)
                            {
                                AuditIdeaEntity auditIdeaEntityInsert = new AuditIdeaEntity();
                                auditIdeaEntityInsert.IdeaId = id;
                                auditIdeaEntityInsert.RecordUpdateId = recordId;
                                auditIdeaEntityInsert.AttributeName = keyPayLoad;
                                auditIdeaEntityInsert.OldValue = IdeaDicEntity[keyEntity].ToString();
                                auditIdeaEntityInsert.UpdatedValue = dataKeyValue[keyPayLoad].ToString();
                                auditIdeaEntityInsert.Deleted = false;
                                auditIdeaEntityInsert.CreatedDate = DateTime.Now;
                                auditIdeaEntityInsert.CreatedBy = "";
                                _savingIdeaDataContext.AuditIdeas.Add(auditIdeaEntityInsert);
                                await _savingIdeaDataContext.SaveChangesAsync()
                                    .ConfigureAwait(false);
                                IdeaDicEntity[keyEntity] = dataKeyValue[keyPayLoad];
                            }
                           
                        }
                        if (keyEntity == "LastUpdated")
                        {

                            IdeaDicEntity[keyEntity] = DateTime.Now;
                        }
                    }  
                }
                var savingIdea = JsonConvert.DeserializeObject<IdeaEntity>(JsonConvert.SerializeObject(IdeaDicEntity));
                _savingIdeaDataContext.Ideas.Update(savingIdea);
                await _savingIdeaDataContext.SaveChangesAsync()
                    .ConfigureAwait(false);
                var a = auditKeyValue;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public async Task DeleteIdeaByIdAsync(int ideaId)
        {
            try
            {
                _savingIdeaDataContext.Ideas.Remove(new IdeaEntity() {IdeaId = ideaId});
                await _savingIdeaDataContext.SaveChangesAsync()
                    .ConfigureAwait(false);
                return;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

    }


}