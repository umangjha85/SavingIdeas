﻿using System;

namespace SavingIdeas.EFCore.Models
{
    public class AuditIdeaEntity
    {
        public int AuditIdeaId { get; set; }
        public Guid RecordUpdateId { get; set; }
        public int? IdeaId { get; set; }
        public IdeaEntity IdeaEntity { get; set; }
        public string AttributeName { get; set; }
        public string OldValue { get; set; }
        public string UpdatedValue { get; set; }
        public bool Deleted { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }
}
