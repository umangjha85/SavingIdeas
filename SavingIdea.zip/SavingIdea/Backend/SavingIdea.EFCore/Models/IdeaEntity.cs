﻿using System;
using System.Collections.Generic;

namespace SavingIdeas.EFCore.Models
{
    public class IdeaEntity
    {
        public ICollection<AuditIdeaEntity> AuditData { get; set; }
        public int? IdeaId { get; set; }
        public string Year { get; set; }
        public string Sector { get; set; }
        public string L1Commodity { get; set; }
        public string SupplierCode { get; set; }
        public string SupplierName { get; set; }
        public string Responsibility { get; set; }
        public string L5Commodity { get; set; }
        public string Part { get; set; }
        public string PartDescription { get; set; }
        public string NegoSavingLever { get; set; }
        public string DerivedthruSpendAnalyticsYN { get; set; }
        public string ApplicableModel { get; set; }
        public double? SavingVehor { get; set; }
        public double? ApplicableSupplierVolume { get; set; }
        public double? F20CashflowSavingRsCrs { get; set; }
        public string ConfidenceLevel { get; set; }
        public string SaPCN { get; set; }
        public DateTime? EffectivityDate { get; set; }
        public string Remarks { get; set; }
        public string ImplementationStatus { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? LastUpdated { get; set; }
    }
}
