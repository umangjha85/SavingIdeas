﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SavingIdeas.EFCore.Migration.Migrations
{
    public partial class audit : Microsoft.EntityFrameworkCore.Migrations.Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dba");

            migrationBuilder.CreateTable(
                name: "Idea",
                schema: "dba",
                columns: table => new
                {
                    IdeaId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Year = table.Column<string>(nullable: true),
                    Sector = table.Column<string>(nullable: true),
                    L1Commodity = table.Column<string>(nullable: true),
                    SupplierCode = table.Column<string>(nullable: true),
                    SupplierName = table.Column<string>(nullable: true),
                    Responsibility = table.Column<string>(nullable: true),
                    L5Commodity = table.Column<string>(nullable: true),
                    Part = table.Column<string>(nullable: true),
                    PartDescription = table.Column<string>(nullable: true),
                    NegoSavingLever = table.Column<string>(nullable: true),
                    DerivedthruSpendAnalyticsYN = table.Column<string>(nullable: true),
                    ApplicableModel = table.Column<string>(nullable: true),
                    SavingVehor = table.Column<double>(nullable: true),
                    ApplicableSupplierVolume = table.Column<double>(nullable: true),
                    F20CashflowSavingRsCrs = table.Column<double>(nullable: true),
                    ConfidenceLevel = table.Column<string>(nullable: true),
                    SaPCN = table.Column<string>(nullable: true),
                    EffectivityDate = table.Column<DateTime>(nullable: true),
                    Remarks = table.Column<string>(nullable: true),
                    ImplementationStatus = table.Column<string>(nullable: true),
                    Created = table.Column<DateTime>(nullable: true, defaultValueSql: "getdate()"),
                    LastUpdated = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Idea", x => x.IdeaId);
                });

            migrationBuilder.CreateTable(
                name: "AuditIdea",
                schema: "dba",
                columns: table => new
                {
                    AuditIdeaId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RecordUpdateId = table.Column<Guid>(nullable: false),
                    IdeaId = table.Column<int>(nullable: true),
                    IdeaEntityIdeaId = table.Column<int>(nullable: true),
                    AttributeName = table.Column<string>(nullable: true),
                    OldValue = table.Column<string>(nullable: true),
                    UpdatedValue = table.Column<string>(nullable: true),
                    Deleted = table.Column<bool>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditIdea", x => x.AuditIdeaId);
                    table.ForeignKey(
                        name: "FK_AuditIdea_Idea_IdeaEntityIdeaId",
                        column: x => x.IdeaEntityIdeaId,
                        principalSchema: "dba",
                        principalTable: "Idea",
                        principalColumn: "IdeaId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AuditIdea_IdeaEntityIdeaId",
                schema: "dba",
                table: "AuditIdea",
                column: "IdeaEntityIdeaId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AuditIdea",
                schema: "dba");

            migrationBuilder.DropTable(
                name: "Idea",
                schema: "dba");
        }
    }
}
