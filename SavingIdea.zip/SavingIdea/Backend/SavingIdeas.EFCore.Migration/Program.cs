﻿using Microsoft.EntityFrameworkCore;
using SavingIdeas.EFCore.DataContext;
using System;

namespace SavingIdeas.EFCore.Migration
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var data=new DataContext();
        }
    }

    public class DataContext : SavingIdeaDataContext
    {

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var savingIdeaConnectionString =
                "Server=DESKTOP-Q7PLAVM;Integrated Security=false;Initial Catalog=SavingIdea;User ID=sa;Password=umang123;";
            optionsBuilder.UseSqlServer(savingIdeaConnectionString);
            //optionsBuilder.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
            //optionsBuilder.EnableSensitiveDataLogging(true);
            base.OnConfiguring(optionsBuilder);
        }

    }
}
